package com.example.trymbgsm2;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    MBgsm mBgsm;
    TextView textView;
    private PhoneStateListener phoneStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        ContextCompat
        final Context applicationContext = getApplicationContext();
//        if (ContextCompat )
        //检查系统是否开启了地理位置权限;
        //注意：此时的Manifest的导入包路径import android.Manifest;
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},1 );
        }
        mBgsm = new MBgsm(applicationContext);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            applicationContext.startForegroundService(new Intent(applicationContext, MBgsm.class));
//        } else {
//            applicationContext.startService(new Intent(applicationContext, MBgsm.class));
//        }
        Button button = (Button) findViewById(R.id.button100);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(applicationContext,mBgsm.getTempstring(),Toast.LENGTH_LONG).show();
            }
        });

        final Button button101 = (Button) findViewById(R.id.button101);
        button101.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.button101){
                    postWithOkHttp();
                }
            }
        });

        textView = (TextView) findViewById(R.id.textmsg);
        textView.setText(""+"服务小区\n"+mBgsm.getMaster()+"\n相邻小区\n"+mBgsm.getCellLte());
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//
//    }

    private void postWithOkHttp(){
        //开启线程来发起网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    FormBody.Builder builder =new FormBody.Builder();
//                    builder.add("username","test1");
//                    builder.add("password","test1");
                    builder.add("LteMaster",mBgsm.getMaster());
                    builder.add("Ltener",mBgsm.getCellLte());
//                    builder.add("LteMaster","123");
//                    builder.add("Ltener","123");
                    RequestBody formBody =builder.build();

                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder()
                            .url("http://192.168.0.113:8900/test")     //修改为.json地址
                            .post(formBody)
                            .build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    Log.d("MainActivity",responseData);
                    //praseJsonWithJSONObject(responseData);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
