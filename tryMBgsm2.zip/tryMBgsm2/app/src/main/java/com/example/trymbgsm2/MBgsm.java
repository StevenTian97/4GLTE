package com.example.trymbgsm2;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telecom.TelecomManager;
import android.telephony.CellInfo;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.CellLocation;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;

import java.util.ArrayList;
import java.util.List;

public class MBgsm {
    Context mcontext;

    TelephonyManager mTelephonyManager;
    CellLocation mCellLocation;

    public String[] MB1 = new String[3];  //外部调用输入参数
    public String[] MB0 = new String[20];  //向外部输出的参数
    public String[] MB2 = new String[3];
    //网络变化状态,MB2[0]信号强度变化，MB2[1]小区切换，MB2[2]以上两者都变化。
    //没变化为空(""),有变化为("change")
    private String Tempstring = "";
    private int Tempint = 0;


    public MBgsm(Context context) {
        this.mcontext = context;
        for (Tempint = 0; Tempint < MB1.length; Tempint++) {
            MB1[Tempint] = "";
        }
        for (Tempint = 0; Tempint < MB0.length; Tempint++) {
            MB0[Tempint] = "";
        }
        for (Tempint = 0; Tempint < MB2.length; Tempint++) {
            MB2[Tempint] = "";
        }
    }

    public String getTempstring(){
        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
//        String imeiCode = null;
//        try {
//            if (ActivityCompat.checkSelfPermission(mcontext, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                imeiCode = mTelephonyManager.getDeviceId();
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        if (ActivityCompat.checkSelfPermission(
//                mcontext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
//                && ActivityCompat.checkSelfPermission(mcontext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//        if(ContextCompat.checkSelfPermission(mcontext, Manifest.permission.ACCESS_COARSE_LOCATION)
//                != PackageManager.PERMISSION_GRANTED){
        GsmCellLocation gsmCellLocation = (GsmCellLocation) mTelephonyManager.getCellLocation();
        List<Integer> list = new ArrayList<>();
        list.add(gsmCellLocation.getLac());
        list.add(gsmCellLocation.getCid());
        list.add(gsmCellLocation.getPsc());
            return list.toString();
//        }else {
//            return "false";
//        }
//        String networkOperator = mTelephonyManager.getNetworkOperator();
//        networkOperator.substring(0,3);


    }

    public String getCellLte(){
        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
//        SignalStrength signalStrength = mTelephonyManager.getSignalStrength();
        List<CellInfo> allCellInfo = mTelephonyManager.getAllCellInfo();
        List<String> list = new ArrayList();
        int size = allCellInfo.size();
        for (CellInfo cellInfo : allCellInfo) {
//            CellInfoGsm cellInfoGsm = (CellInfoGsm) cellInfo;
//            CellInfoWcdma cellInfoWcdma = (CellInfoWcdma) cellInfo;
            if (cellInfo instanceof CellInfoLte) {
                CellInfoLte cellInfoLte = (CellInfoLte) cellInfo;
                String s = cellInfoLte.toString();
//            int dbm = cellInfoLte.getCellSignalStrength().getDbm();
//            int cid = cellInfoLte.getCellIdentity().getCid();
                list.add(s);
//                return list.toString() + "\n" + s1;
            }
        }
        return list.toString();
    }


    public int getNetworkType(){
        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
        int networkType = mTelephonyManager.getNetworkType();
        return networkType;
    }

    public String getMaster(){
        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
        SignalStrength signalStrength = mTelephonyManager.getSignalStrength();
        String s1 = signalStrength.toString();
        int networkType = getNetworkType();
        return String.valueOf(networkType) + "," + getTempstring()+ "," + s1;
    }

//    public int getCid(){
//        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
//        GsmCellLocation gsmCellLocation = (GsmCellLocation) mTelephonyManager.getCellLocation();
//        int cid = gsmCellLocation.getCid(); //获取gsm基站识别标号
//        return cid;
//    }
//
//    public int getLac(){
//        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
//        GsmCellLocation gsmCellLocation = (GsmCellLocation) mTelephonyManager.getCellLocation();
//        int lac = gsmCellLocation.getLac(); //获取gsm网络编号
//        return lac;
//    }
//
//    public int getPsc(){
//        mTelephonyManager = (TelephonyManager) mcontext.getSystemService(mcontext.TELEPHONY_SERVICE);
//        GsmCellLocation gsmCellLocation = (GsmCellLocation) mTelephonyManager.getCellLocation();
//        int psc = gsmCellLocation.getPsc(); //获取gsm网络编号
//        return psc;
//    }
}
